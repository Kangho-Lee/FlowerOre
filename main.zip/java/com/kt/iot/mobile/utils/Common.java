package com.kt.iot.mobile.utils;

/**
 * Created by ceoko on 15. 6. 30..
 */
public class Common {

    /*public static final String CLIENT_ID = "YzgwOWMxZTJiYTMxNDliZDg2NDk3YmI5NWJmMmJkNWIxNDMyODg0MjM5Nzg2";
    public static final String CLIENT_SECRET = "ZTVhNWM5ZmYxNDY1NDE3YWFlM2M1N2ViMzg4NjAyODUxNDMyODg0MjM5Nzg2";*/

    /*public static final String CLIENT_ID = "ODE0Y2Y4MjktODEyNS00ZTUyLWIxOTQtZDE2M2RlMmRjYTI0MTQzNTY1NTEwODMzM+WXsO6tsu6oqeauqO61mOWErOaoveuHnuulhuqKoQ==";
    public static final String CLIENT_SECRET = "ZGM1NjdmNjAtYjg0Mi00Y2FmLWJkODUtNGNhOGI1OTE2NWEyMTQzNTY1NTEwODMzM+aElOu0rO2CqOu8leuQjeq5ku+MieSOu+emjOK6tA==";*/

    //
    public static final String CLIENT_ID = "MjhhNmI1YmUtNThjMi00M2EzLWFmNWUtYjI2NDQyNmI5Y2RlMTQzNjg1OTAxOTU3Mz8/Pz8/Pz8/Pz8=";
    public static final String CLIENT_SECRET = "NWE1ZmNiMzUtNzA2OS00OWFiLTkyNDUtMGI0MzA1MmJiMzc5MTQzNjg1OTAxOTU3Mz8/Pz8/Pz8/";

}
